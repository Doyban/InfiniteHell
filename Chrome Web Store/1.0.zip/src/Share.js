var InfiniteHell = InfiniteHell || {};

InfiniteHell.Share = function(){};

InfiniteHell.Share.prototype = {
    
};