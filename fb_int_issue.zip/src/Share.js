var InfiniteHell = InfiniteHell || {};

InfiniteHell.Share = function(){};

InfiniteHell.Share.prototype = {
//    window.fbAsyncInit = function() {
//    FB.init({
//      appId      : '611658819003576',
//      xfbml      : true,
//      version    : 'v2.6'
//    });
//
//    // ADD ADDITIONAL FACEBOOK CODE HERE
//    // Place following code after FB.init call.
//
//    function onLogin(response) {
//      if (response.status == 'connected') {
//        FB.api('/me?fields=first_name', function(data) {
//          var welcomeBlock = document.getElementById('fb-welcome');
//          welcomeBlock.innerHTML = 'Hello, ' + data.first_name + '!';
//        });
//      }
//    },
//
//function shareScore(n){
//     FB.ui({
//          method: "feed",
//          link: "https://apps.facebook.com/risky-steps/",
//          caption: "Play Risky Steps now!!",
//          name: "My best score on Risky steps is " + n + "!!!!",
//          description: "I scored " + n + " points on Risky Steps. Can you beat my score?",
//          picture: "https://www.feronato.com/facebook/risky-steps/assets/pictures/feedpic.png"
//     }, function(response){});
//}
//
//    FB.getLoginStatus(function(response) {
//      // Check login status on load, and if the user is
//      // already logged in, go directly to the welcome message.
//      if (response.status == 'connected') {
//        onLogin(response);
//      } else {
//        // Otherwise, show Login dialog first.
//        FB.login(function(response) {
//          onLogin(response);
//        }, {scope: 'user_friends, email'});
//      }
//    });
//  };
//
//  (function(d, s, id){
//     var js, fjs = d.getElementsByTagName(s)[0];
//     if (d.getElementById(id)) {return;}
//     js = d.createElement(s); js.id = id;
//     js.src = "//connect.facebook.net/en_US/sdk.js";
//     fjs.parentNode.insertBefore(js, fjs);
//   }(document, 'script', 'facebook-jssdk'));
};